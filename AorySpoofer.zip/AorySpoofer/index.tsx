/*
 * AorySpoofer — dérivé de PlatformSpoofer (Equicord ; auteurs : Drag, neoarz)
 * Vencord, a Discord client mod
 * Copyright (c) 2023 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 *
 * Version réduite : une seule plateforme annoncée à Discord, « VR ».
 * (Les propriétés VR sont celles de l'ancienne option « VR » de PlatformSpoofer.)
 */

import { Notice } from "@components/Notice";
import { EquicordDevs } from "@utils/constants";
import definePlugin from "@utils/types";

export default definePlugin({
    name: "AorySpoofer",
    description: "Annonce ton client Discord comme étant en VR (plus d'icône PC pour la session en cours)",
    tags: ["Utility"],
    authors: [EquicordDevs.Drag, EquicordDevs.neoarz],
    restartNeeded: true,
    settingsAboutComponent: () => (
        <Notice.Warning>
            Impossible de garantir que ce plugin ne te vaudra pas un avertissement ou un bannissement. Le mode VR peut aussi faire passer ton client pour une version obsolète. Redémarre Discord après l'avoir activé.
        </Notice.Warning>
    ),
    patches: [
        {
            find: "_doIdentify(){",
            replacement: [
                {
                    match: /window._ws=null,null!=\i/,
                    replace: "false"
                },
                {
                    match: /(?<=\"GatewaySocket\"\)\}\),properties:)(\i)/,
                    replace: "{...$1,...$self.getProperties()}"
                },
            ]
        }
    ],
    getProperties() {
        return { os: "android", browser: "Discord VR", device: "Discord VR" };
    }
});
