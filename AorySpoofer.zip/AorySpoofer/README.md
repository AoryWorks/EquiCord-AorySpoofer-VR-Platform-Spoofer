# AorySpoofer

Plateforme annoncée : VR uniquement (aucun réglage).
Basé sur PlatformSpoofer d'Equicord (Drag, neoarz), GPL-3.0-or-later.
À placer dans `Equicord\src\userplugins\AorySpoofer\` puis `pnpm build` et `pnpm inject`.
Supprime l'ancien dossier `AoryPlatformSpoofer` pour éviter un doublon.
